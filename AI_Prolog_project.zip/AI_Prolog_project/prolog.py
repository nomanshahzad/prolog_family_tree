from pyswip import Prolog
prolog = Prolog()
prolog.consult("khanfamily.pl")
menu = """
\t\t\t\tWhich Relation You Want to Find......?
\t\t\t\tPress :
\t\t---------------------------------------------------------------------------------------------------------------
\t\t|                                                                                                             |
\t\t|    (1)  for baap\t(2)  for maa\t(3)  for beta\t(4)  for beti\t(5)  for dada\t(6)  for dadi         |
\t\t|    (7)  for nana\t(8)  for nani\t(9)  for sala\t(10) for sali\t(11) for bahu\t(12) for damad        |
\t\t|    (13) for pota\t(14) for poti\t(15) for nawasa\t(16) for nawasi\t(17) for sussar\t(18) for chachataya   |
\t\t|                            (19) for khala \t(20) for baap dada                                            |
\t\t---------------------------------------------------------------------------------------------------------------
"""

while (True):
    print(menu)
    choice = int(input("\t\t\t\t\t\tEnter Your Choice : "))
    if(choice == 1):
        choice2 = (input(
            """\t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t""")).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")
            for soln in prolog.query(f"baap(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the father of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is father of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"baap(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"baap(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 2):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")
            for soln in prolog.query(f"maa(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the mother of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is mother of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"maa(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"maa(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 3):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")
            for soln in prolog.query(f"beta(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the son of", name)
                print("\t\t\t\t\t\t------------------------------------")
        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is son of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"beta(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"beta(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 4):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")
            for soln in prolog.query(f"beti(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the daughter of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is daughter of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"beti(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"beti(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 5):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")
            for soln in prolog.query(f"dada(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the dada of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is dada of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"dada(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"dada(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 6):
        name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

        for soln in prolog.query(f"dadi(X,{name})"):
            print("\t\t\t\t\t\t------------------------------------")
            print("\t\t\t\t\t\t", soln["X"], "is the dadi of", name)
            print("\t\t\t\t\t\t------------------------------------")

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"dadi(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the dadi of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is dadi of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"dadi(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"dadi(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 7):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"nana(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the nana of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is nana of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"nana(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"nana(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 8):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"nani(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the nani of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is nani of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"nani(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"nani(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 9):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"sala(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the sala of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is sala of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"sala(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"sala(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 10):

        choice2 = input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"sali(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the sali of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is sali of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"sali(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"sali(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 11):
        name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

        for soln in prolog.query(f"bahu(X,{name})"):
            print("\t\t\t\t\t\t------------------------------------")
            print("\t\t\t\t\t\t", soln["X"], "is the bahu of", name)
            print("\t\t\t\t\t\t------------------------------------")

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"bahu(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the bahu of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is bahu of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"bahu(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"bahu(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 12):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"damad(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the damad of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is damad of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"damad(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"damad(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 13):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"pota(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the pota of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is pota of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"pota(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"pota(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 14):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"poti(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the poti of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is poti of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"poti(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"poti(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 15):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"nawasa(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the nawasa of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is nawasa of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"nawasa(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"nawasa(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 16):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"nawasi(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the nawasi of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is nawasi of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"nawasi(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"nawasi(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 17):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"sassur(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the sassur of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is sassur of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"sassur(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"sassur(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 18):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"chachataya(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the chachataya of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is chachataya of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"chachataya(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"chachataya(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 19):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"khala(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the khala of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is khala of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"khala(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"khala(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")

    elif(choice == 20):

        choice2 = (input(
            """ \t\t\t\tEnter 'a' for simple query\tEnter 'b' for validating query:\n\t\t\t\t\t\t\t\n   """)).lower().replace(" ", "")
        if choice2 == "a":
            name = (input("\t\t\t\t\t\tEnter Name: ")).lower().replace(" ", "")

            for soln in prolog.query(f"baapdada(X,{name})"):
                print("\t\t\t\t\t\t------------------------------------")
                print("\t\t\t\t\t\t", soln["X"], "is the baapdada of", name)
                print("\t\t\t\t\t\t------------------------------------")

        elif choice2 == "b":
            fact1, fact2 = (input("fact 1 : ")).lower().replace(" ", ""), (input(
                "is baapdada of : ")).lower().replace(" ", "")
            if len(list(prolog.query(f"baapdada(X,{fact2})"))) == 0:
                print("false")
            else:
                for soln in prolog.query(f"baapdada(X,{fact2})"):
                    if(soln["X"] == fact1):
                        istrue = True
                        break
                    else:
                        istrue = False
                print(istrue)
        else:
            print("         Invalid Choice........")
    word = (input("\t\t\t\t\t\tPress 'y' to continue 'n' to exit:  ")).lower()
    if (word == 'n'):
        break
